# Helper Code

I keep a personal folder with a series of quick sketches that let me test a component or a piece of code quickly. As your circuits become more and more complex, debugging becomes increasingly difficult since problems can be electrical, software or some combination of both.

These are a few examples to get you started but you should create and add your own here as well.
